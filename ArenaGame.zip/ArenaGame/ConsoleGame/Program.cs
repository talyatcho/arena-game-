﻿using ArenaGame;

namespace ConsoleGame
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter number of battles: ");
            int rounds = Int32.Parse(Console.ReadLine());
            int oneWins = 0, twoWins = 0;

            for (int i = 0; i < rounds; i++)
            {
                // Първи двубой
                Hero one = new Knight("Sir Lancelot") { Weapon = new Knife() };
                Hero two = new Rogue("Robin Hood") { Weapon = new Bow() };
                Console.WriteLine($"Arena fight between: {one.Name} and {two.Name}");
                Arena arenaOne = new Arena(one, two);
                Hero winnerOne = arenaOne.Battle();
                Console.WriteLine($"Winner of first battle: {winnerOne.Name}");
                if (winnerOne == one) oneWins++; else twoWins++;

                // Втори двубой
                Hero three = new Mage("Jon") { Weapon = new Axe() };
                Hero four = new Barbarian("Jacks") { Weapon = new Knife() };
                Console.WriteLine($"Arena fight between: {three.Name} and {four.Name}");
                Arena arenaTwo = new Arena(three, four);
                Hero winnerTwo = arenaTwo.Battle();
                Console.WriteLine($"Winner of second battle: {winnerTwo.Name}");
                if (winnerTwo == three) oneWins++; else twoWins++;

                // Финална битка между победителите от първите два двубоя
                Console.WriteLine($"Final battle between: {winnerOne.Name} and {winnerTwo.Name}");
                Arena finalArena = new Arena(winnerOne, winnerTwo);
                Hero finalWinner = finalArena.Battle();
                Console.WriteLine($"Winner of the final battle: {finalWinner.Name}");
                if (finalWinner == winnerOne) oneWins++; else twoWins++;
            }

            Console.WriteLine();
            Console.WriteLine($"One has {oneWins} wins.");
            Console.WriteLine($"Two has {twoWins} wins.");

            Console.ReadLine();
        }
    }
}

