﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
     public abstract class Weapon
    {
        public string Name { get; protected set; }
        public int DamageBonus { get; protected set; }

        public Weapon(string name, int damageBonus)
        {
            Name = name;
            DamageBonus = damageBonus;
        }

        public abstract int CalculateDamage(int baseDamage);
    }
    public class Knife : Weapon
    {
        public Knife() : base("Knife", 20) { }

        public override int CalculateDamage(int baseDamage)
        {
            return baseDamage + DamageBonus;
        }
    }

    public class Bow : Weapon
    {
        public Bow() : base("Bow", 15) { }

        public override int CalculateDamage(int baseDamage)
        {
            // 10% шанс за удвояване на атаката
            if (Random.Shared.Next(100) < 10)
            {
                return baseDamage + DamageBonus * 2;
            }
            return baseDamage + DamageBonus;
        }
    }

    public class Axe : Weapon
    {
        public Axe() : base("Axe", 25) { }

        public override int CalculateDamage(int baseDamage)
        {
            // 5% шанс за триплиране на атаката
            if (Random.Shared.Next(100) < 5)
            {
                return baseDamage + DamageBonus * 3;
            }
            return baseDamage + DamageBonus;
        }
    }

}

