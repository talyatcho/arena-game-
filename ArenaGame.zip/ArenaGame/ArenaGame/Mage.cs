﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Mage : Hero
    {
        public Mage(string name) : base(name) { }

        public override int Attack()
        {
            int baseDamage = base.Attack();
            // 20% шанс за двойна атака
            if (ThrowDice(20))
            {
                baseDamage *= 2;
            }
            return baseDamage;
        }

        public override void TakeDamage(int incomingDamage)
        {
            // 10% шанс за игнориране на щетите
            if (ThrowDice(10))
            {
                incomingDamage = 0;
            }
            base.TakeDamage(incomingDamage);
        }
    }

    public class Barbarian : Hero
    {
        public Barbarian(string name) : base(name) { }

        public override int Attack()
        {
            int baseDamage = base.Attack();
            // 15% шанс за троен удар
            if (ThrowDice(15))
            {
                baseDamage *= 3;
            }
            return baseDamage;
        }

        public override void TakeDamage(int incomingDamage)
        {
            // 5% шанс за намаляване на щетите с 50%
            if (ThrowDice(5))
            {
                incomingDamage /= 2;
            }
            base.TakeDamage(incomingDamage);
        }
    }

}
